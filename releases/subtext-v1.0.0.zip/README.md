# SubText (ST//) — Minimalist YouTube Subtitle Extractor

A fast, lightweight, and distraction-free Chrome extension to preview, copy, and download clean YouTube subtitles and auto-generated captions in `.txt` or `.srt` formats.

Designed with a utilitarian monochrome aesthetic and **JetBrains Mono**.

---

## ✨ Features

- **One-Click In-Page Button**: Adds a minimal `[ ST// Subtitles ]` button right inside YouTube's action bar (beside Like/Share).
- **JetBrains Mono Minimalist UI**: Dark charcoal monochrome aesthetic with zero clutter.
- **Auto-Captions & Multilingual**: Automatically extracts English auto-generated captions (`a.en`), standard English, or any available track on the video.
- **Multiple Export Formats**:
  - **`prose .txt`**: Continuous sentence flow with paragraphs (ideal for reading, note-taking, or pasting into ChatGPT/Claude).
  - **`lines .txt`**: Spoken subtitle segments line-by-line.
  - **`timed .txt`**: Text prefixed with `[HH:MM:SS]` timestamps.
  - **`srt .srt`**: Standard SubRip format for video editing and media players.
- **Live Preview & Stats**: Word counter, character counter, segment counter, and monospace live preview.
- **Instant Copy**: Copy full transcripts directly to your clipboard in one click.
- **No Third-Party Servers**: Runs 100% locally in your browser. No data leaves your machine.

---

## 🚀 Installation (100% Free via Developer Mode)

You do **not** need a paid Chrome Web Store developer account to use or share SubText.

### Method 1: Load from Source (Recommended)

1. Clone or download this repository:
   ```bash
   git clone https://github.com/your-username/subtext.git
   ```
   *(Or download the `.zip` from Releases and extract it to a folder).*
2. Open Google Chrome (or Brave, Edge, Opera, Vivaldi).
3. Navigate to `chrome://extensions` in the address bar.
4. Toggle **Developer mode** on in the top-right corner.
5. Click **Load unpacked** (top-left).
6. Select the `yt-subtitles-minimal` directory (the folder containing `manifest.json`).
7. Done! Pin SubText to your browser toolbar for quick access.

---

### Method 2: Package as a `.crx` File (For Direct Sharing)

If you want to create a standalone `.crx` file to share:

1. Open `chrome://extensions`.
2. Ensure **Developer mode** is enabled.
3. Click the **Pack extension** button.
4. Set **Extension root directory** to the folder containing `manifest.json`.
5. Leave the private key field blank for the first pack (Chrome will generate a `.pem` file).
6. Click **Pack extension**. Chrome will generate:
   - `subtext.crx` (the installer file)
   - `subtext.pem` (your private signing key — keep this safe to sign future updates).
7. To install the `.crx` on another computer:
   - Open `chrome://extensions` on that computer.
   - Turn on **Developer mode**.
   - Drag and drop the `.crx` file directly into the page.

---

## 🛠️ Project Structure

```text
yt-subtitles-minimal/
├── manifest.json       # Manifest V3 extension configuration
├── popup.html          # Monospace popup layout
├── popup.css           # JetBrains Mono minimal dark styling
├── popup.js            # Transcript extractor, formatters & downloader
├── content.js          # In-page button injector & one-click extractor
├── content.css         # Styling for YouTube in-page button
├── icon16.png          # Favicon icon
├── icon48.png          # Extensions manager icon
├── icon128.png         # High-res icon
├── pack.ps1            # Release packaging script
└── README.md           # Documentation
```

---

## 📄 License

MIT License. Free to use, modify, and distribute.
